Run the following commands to run the code on your local machine

open the terminal where you want your project to save
```
git clone https://github.com/kamesh-ie/Articuno-Coding-LLP

cd Articuno-Coding-LLP

pip install -r requirements.txt

python manage.py migrate

python manage.py runserver
```

open your browser and type ` localhost:8000 ` to view the app